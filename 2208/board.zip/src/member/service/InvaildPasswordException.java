package member.service;

public class InvaildPasswordException extends RuntimeException{

}
