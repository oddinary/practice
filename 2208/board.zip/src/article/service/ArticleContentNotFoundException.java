package article.service;

public class ArticleContentNotFoundException extends RuntimeException{

}
